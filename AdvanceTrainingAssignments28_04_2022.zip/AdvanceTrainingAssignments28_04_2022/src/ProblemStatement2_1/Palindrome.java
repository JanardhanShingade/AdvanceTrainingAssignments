package ProblemStatement2_1;

import java.util.Scanner;

public class Palindrome {


    public static void main(String args[])
    {
        String a, b = "";
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the string you want to check:");
        a = s.nextLine();
        a = a.toUpperCase();
        int n = a.length();
        System.out.print("Length of the string:" + n);
        System.out.println();
        for(int i = n - 1; i >= 0; i--)
        {
            b = b + a.charAt(i);
        }
        if(a.equalsIgnoreCase(b))
        {
            System.out.println(a +" is palindrome.");
        }
        else
        {
            System.out.println(a +" is not palindrome.");
        }
    }
}
