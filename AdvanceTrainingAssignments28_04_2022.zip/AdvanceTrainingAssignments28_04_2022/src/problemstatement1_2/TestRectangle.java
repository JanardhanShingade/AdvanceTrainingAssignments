package problemstatement1_2;

public class TestRectangle extends App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Rectangle r2 = new Rectangle(4, 4);
		Rectangle r3 = new Rectangle(6, 4);
		Rectangle r4 = new Rectangle(8, 6);
		Rectangle r5 = new Rectangle(10, 4);
		
		r2.printData();
		r2.printArea();
	
		
		r3.printData();
		r3.printArea();
		
		
		r4.printData();
		r4.printArea();
		
		
		r5.printData();
		r5.printArea();

	}

}
