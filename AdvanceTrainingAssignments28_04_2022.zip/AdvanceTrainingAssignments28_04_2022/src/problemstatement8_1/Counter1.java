package problemstatement8_1;

public class Counter1 {
	public static void main(String args[])

	{

	Counter counter = new Counter(25);

	counter.run();

	}
}
