package ProblemStatement1_4;



public class Test_Rectangle extends Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Rectangle1 r2 = new Rectangle1(5,3);
		Rectangle1 r3 = new Rectangle1(6, 4);
		Rectangle1 r4 = new Rectangle1(8, 6);
		Rectangle1 r5 = new Rectangle1(10, 4);
		
		r2.printData();
		r2.printArea();
		r2.printPerimeter();
	
		System.out.println();
		
		r3.printData();
		r3.printArea();
		r3.printPerimeter();
		System.out.println();
		
		r4.printData();
		r4.printArea();
		r4.printPerimeter();
		System.out.println();
		
		r5.printData();
		r5.printArea();
		r5.printPerimeter();
		System.out.println();
	}

}
