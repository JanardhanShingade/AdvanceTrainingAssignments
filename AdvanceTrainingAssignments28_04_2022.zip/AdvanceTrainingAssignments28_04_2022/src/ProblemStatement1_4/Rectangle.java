package ProblemStatement1_4;


class Rectangle1 {
	private int length;
	private int breadth;


	public Rectangle1() {
	}

	
	public Rectangle1(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}


	
	public void printData() {
		System.out.println("Length: " + length);
		System.out.println("Breadth: " + breadth);
	}


	public void printArea() {
		int area = length * breadth;
		System.out.println("Area: " + area);
	}


	public void printPerimeter() {
		int perimeter = 2 * (length + breadth);
		System.out.println("Perimeter: " + perimeter);
	}
}

public class Rectangle {

	
	public static void main(String[] args) {
}
}