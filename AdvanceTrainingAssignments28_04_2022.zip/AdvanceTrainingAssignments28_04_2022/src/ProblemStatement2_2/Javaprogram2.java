package ProblemStatement2_2;

import java.util.Scanner;

public class Javaprogram2 {

public static void main(String args[]){
	 Scanner Obj = new Scanner(System.in);
	 System.out.print("Enter Fisrst number: ");
	 int n1= Obj.nextInt();
	 System.out.print("Enter Second number: ");
	 int n2 = Obj.nextInt();
	 
 int n3,i,count=14;  
 System.out.print(n1+" "+n2);  
  
 for(i=2;i<count;++i) 
 {  
  n3=n1+n2;  
  System.out.print(" "+n3);  
  n1=n2;  
  n2=n3;  
 } 
 
}

}